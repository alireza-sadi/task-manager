

<?php $__env->startSection('content'); ?>
    <h1>SHOW</h1>

    <table class="table">
        <tr>
            <th class="text-center">task ID</th>
            <th class="text-center">task Title</th>
            <th class="text-center">task Description</th>
            <th class="text-center">Is done ?</th>
            <th class="text-center">Opretions</th>
        </tr>
    <tr>
        <td class="text-center"> <?php echo e($task->id); ?></td>
        <td class="text-center"> <h4><?php echo e($task->title); ?></h4></td>
        <td class="text-center"><?php echo e($task->description); ?></td>
        <?php if($task->is_done == 1): ?>
            <td class="text-center">Yes</td>
            <?php else: ?>
            <td class="text-center">No</td>
        <?php endif; ?>


        <form action="<?php echo e(route('tasks.destroy',$task->id)); ?>" method="POST">
        <td class="text-center">
            <button class="btn btn-info me-2"><a href="<?php echo e(route('tasks.edit',$task->id)); ?>"class="button">Edit</a></button>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </td>
    </form>
    </tr>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\test\Desktop\laravel project\task-manager\resources\views/tasks/show.blade.php ENDPATH**/ ?>