

<?php $__env->startSection('content'); ?>
    <h1>INDEX</h1>

    <p><?php echo e(Session::get('msg')??""); ?></p>

    <a href="<?php echo e(route('tasks.create')); ?>">New</a>
    
    <hr/>

    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <h3><?php echo e($task->title); ?></h3>    

        <form action="<?php echo e(route('tasks.destroy',$task->id)); ?>" method="POST">
            <a href="<?php echo e(route('tasks.show',$task->id)); ?>">Show</a>
            <a href="<?php echo e(route('tasks.edit',$task->id)); ?>">Edit</a>

            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit">Delete</button>
        </form>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\test\Desktop\laravel project\task-manager\resources\views/users/index.blade.php ENDPATH**/ ?>