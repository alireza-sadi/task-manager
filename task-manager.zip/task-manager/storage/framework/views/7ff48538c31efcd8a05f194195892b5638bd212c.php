

<?php $__env->startSection('content'); ?>
    <h1>CREATE</h1>

    <form action="<?php echo e(route('tasks.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="mb-3">
            <label for="title" class="form-check-label me-2">Task Name: </label>
            <input type="text" name="title">
        </div>
        <div class="mb-3">
            <label for="description" class="form-check-label me-2">Task Description:</label>
            <textarea name="description" id="" cols="30" rows="10"></textarea>
        </div>
        <input type="submit" value="Create" class="btn btn-success">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\test\Desktop\laravel project\task-manager\resources\views/tasks/create.blade.php ENDPATH**/ ?>