

<?php $__env->startSection('content'); ?>
    <h1 class="mb-3">EDIT</h1>

    <form action="<?php echo e(route('tasks.update',$task->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="mb-3">
            <label for="title" class="form-check-label me-2">Task Name: </label>
            <input type="text" name="title" value="<?php echo e($task->title); ?>" placeholder="Title">
        </div>
        <div class="mb-3">
        <label for="description" class="form-check-label me-2">Task Description:</label>
        <textarea name="description" id="" cols="30" rows="10"><?php echo e($task->description); ?></textarea>
    </div>
        <div class="form-check form-switch mb-3">
            <input type="checkbox" name="is_done" <?php echo e($task->is_done ? 'checked' : ''); ?> class="form-check-input">
            <label for="is_done" class="form-check-label">Is done?</label>
        </div>
        <input type="submit" value="Update" class="btn btn-primary">
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\test\Desktop\laravel project\task-manager\resources\views/tasks/edit.blade.php ENDPATH**/ ?>