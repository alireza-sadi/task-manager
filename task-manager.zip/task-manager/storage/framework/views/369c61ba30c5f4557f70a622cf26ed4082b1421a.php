

<?php $__env->startSection('content'); ?>
    <h1>MY TASKS</h1>

    <p><?php echo e(Session::get('msg')??""); ?></p>

    <button class="btn btn-success me-2 "> <a href="<?php echo e(route('tasks.create')); ?>" class="button">New</a> </button>
    
    <hr/>
    <table class="table">
        <tr>
            <th class="text-center">Task Title</th>
            <th class="text-center">Is done</th>
            <th class="text-center">Opretions</th>
        </tr>
    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td class="text-center"> <h3><?php echo e($task->title); ?></h3></td>
        <?php if($task->is_done == 1): ?>
            <td class="text-center">Yes</td>
            <?php else: ?>
            <td class="text-center">No</td>
        <?php endif; ?>


        <form action="<?php echo e(route('tasks.destroy',$task->id)); ?>" method="POST">
        <td class="text-center">
            <button class="btn btn-info me-2"><a href="<?php echo e(route('tasks.show',$task->id)); ?>"class="button">Show</a></button>
            <button class="btn btn-warning me-2"><a href="<?php echo e(route('tasks.edit',$task->id)); ?>"class="button">Edit</a></button>
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Delete</button>
        </td>
    </form>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('tasks.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\test\Desktop\laravel project\task-manager\resources\views/tasks/index.blade.php ENDPATH**/ ?>