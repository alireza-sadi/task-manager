<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use App\Models\Task;
class TaskSeeder extends Seeder
{
    public function run()
    {
        Task::create(["title" => "Task 1", "is_done" => false]);
        Task::create(["title" => "Task 2", "is_done" => false]);
        Task::create(["title" => "Task 3", "is_done" => true]);
    }
}
