@extends('tasks.layout')

@section('content')
    <h1>SHOW</h1>

    <table class="table">
        <tr>
            <th class="text-center">task ID</th>
            <th class="text-center">task Title</th>
            <th class="text-center">task Description</th>
            <th class="text-center">Is done ?</th>
            <th class="text-center">Opretions</th>
        </tr>
    <tr>
        <td class="text-center"> {{$task->id}}</td>
        <td class="text-center"> <h4>{{$task->title}}</h4></td>
        <td class="text-center">{{$task->description}}</td>
        @if ($task->is_done == 1)
            <td class="text-center">Yes</td>
            @else
            <td class="text-center">No</td>
        @endif


        <form action="{{ route('tasks.destroy',$task->id) }}" method="POST">
        <td class="text-center">
            <button class="btn btn-info me-2"><a href="{{ route('tasks.edit',$task->id) }}"class="button">Edit</a></button>
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger">Delete</button>
        </td>
    </form>
    </tr>
    </table>
@endsection