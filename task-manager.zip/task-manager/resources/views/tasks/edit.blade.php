@extends('tasks.layout')

@section('content')
    <h1 class="mb-3">EDIT</h1>

    <form action="{{ route('tasks.update',$task->id) }}" method="POST">
        @csrf
        @method('PUT')
        <div class="mb-3">
            <label for="title" class="form-check-label me-2">Task Name: </label>
            <input type="text" name="title" value="{{ $task->title }}" placeholder="Title">
        </div>
        <div class="mb-3">
        <label for="description" class="form-check-label me-2">Task Description:</label>
        <textarea name="description" id="" cols="30" rows="10">{{ $task->description }}</textarea>
    </div>
        <div class="form-check form-switch mb-3">
            <input type="checkbox" name="is_done" {{ $task->is_done ? 'checked' : '' }} class="form-check-input">
            <label for="is_done" class="form-check-label">Is done?</label>
        </div>
        <input type="submit" value="Update" class="btn btn-primary">
    </form>
@endsection