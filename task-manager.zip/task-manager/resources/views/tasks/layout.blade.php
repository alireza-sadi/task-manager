

<html>
    <head>
        <title>Task Manager Application</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
        <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.3/js/bootstrap.min.js" integrity="sha512-ykZ1QQr0Jy/4ZkvKuqWn4iF3lqPZyij9iRv6sGqLRdTPkY69YX6+7wvVGmsdBbiIfN/8OdsI7HABjvEok6ZopQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
        <style>
            a.button {
    border-radius: 3px;
    color: whitesmoke;
    text-decoration: none;
}
        </style>
    </head>
    <body>
        <button class="btn btn-primary m-2" >
            <a href="{{ route('tasks.index') }}" class="button ">
                Home Page
                </a> 
            </button>
    <div class="container">
        @yield('content')
    </div>
    
    </body>
    </html>