@extends('tasks.layout')

@section('content')
    <h1>CREATE</h1>

    <form action="{{ route('tasks.store') }}" method="POST">
        @csrf
        <div class="mb-3">
            <label for="title" class="form-check-label me-2">Task Name: </label>
            <input type="text" name="title">
        </div>
        <div class="mb-3">
            <label for="description" class="form-check-label me-2">Task Description:</label>
            <textarea name="description" id="" cols="30" rows="10"></textarea>
        </div>
        <input type="submit" value="Create" class="btn btn-success">
    </form>
@endsection