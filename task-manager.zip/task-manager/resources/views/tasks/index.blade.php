@extends('tasks.layout')

@section('content')
    <h1>MY TASKS</h1>

    <p>{{ Session::get('msg')??"" }}</p>

    <button class="btn btn-success me-2 "> <a href="{{ route('tasks.create') }}" class="button">New</a> </button>
    
    <hr/>
    <table class="table">
        <tr>
            <th class="text-center">Task Title</th>
            <th class="text-center">Is done</th>
            <th class="text-center">Opretions</th>
        </tr>
    @foreach ($tasks as $task)
    <tr>
        <td class="text-center"> <h3>{{$task->title}}</h3></td>
        @if ($task->is_done == 1)
            <td class="text-center">Yes</td>
            @else
            <td class="text-center">No</td>
        @endif


        <form action="{{ route('tasks.destroy',$task->id) }}" method="POST">
        <td class="text-center">
            <button class="btn btn-info me-2"><a href="{{ route('tasks.show',$task->id) }}"class="button">Show</a></button>
            <button class="btn btn-warning me-2"><a href="{{ route('tasks.edit',$task->id) }}"class="button">Edit</a></button>
            @csrf
            @method('DELETE')
            <button type="submit" class="btn btn-danger">Delete</button>
        </td>
    </form>
    </tr>
    @endforeach
    </table>
@endsection